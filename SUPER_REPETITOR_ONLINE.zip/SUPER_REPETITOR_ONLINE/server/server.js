import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'db.json');
const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const TOKEN_SECRET = process.env.TOKEN_SECRET || 'CHANGE_THIS_SECRET_BEFORE_DEPLOY';
const MAX_BODY = 15 * 1024 * 1024;

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [], messages: {}, sessions: {} }, null, 2));
}

function readDb() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch { return { users: [], messages: {}, sessions: {} }; }
}
let db = readDb();
function writeDb() {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

function json(res, status, body) {
  const text = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
  });
  res.end(text);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0, chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('body too large'), { code: 413 })); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { reject(Object.assign(new Error('invalid json'), { code: 400 })); }
    });
    req.on('error', reject);
  });
}

const b64 = s => Buffer.from(s).toString('base64url');
function signToken(payload) {
  const body = b64(JSON.stringify(payload));
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
  return body + '.' + sig;
}
function verifyToken(token) {
  try {
    const [body, sig] = String(token || '').split('.');
    if (!body || !sig) return null;
    const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(body).digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}
function auth(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const payload = verifyToken(token);
  if (!payload) return null;
  const user = db.users.find(u => u.id === payload.uid);
  return user ? { user, token } : null;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function checkPassword(password, stored) {
  try {
    const [salt, hash] = String(stored).split(':');
    const actual = crypto.scryptSync(String(password), salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(hash, 'hex'));
  } catch { return false; }
}
function cleanUser(u) {
  const { passwordHash, ...safe } = u;
  return safe;
}
function makeId() { return crypto.randomUUID(); }

// First launch creates the tutor account from environment variables.
if (!db.users.some(u => u.role === 'teacher')) {
  const login = process.env.TEACHER_LOGIN;
  const password = process.env.TEACHER_PASSWORD;
  if (login && password) {
    db.users.push({
      id: makeId(), role: 'teacher', name: 'Елена', login,
      passwordHash: hashPassword(password), theme: 'blue', createdAt: Date.now()
    });
    writeDb();
  }
}

async function route(req, res) {
  if (req.method === 'OPTIONS') return json(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (req.method === 'GET' && pathname === '/api/health') return json(res, 200, { ok: true, service: 'SUPER_REPETITOR', time: new Date().toISOString() });

  if (req.method === 'POST' && pathname === '/api/auth/login') {
    const body = await readBody(req);
    const user = db.users.find(u => u.login === String(body.login || ''));
    if (!user || !checkPassword(body.password || '', user.passwordHash)) return json(res, 401, { ok: false, error: 'Неверный логин или пароль' });
    const token = signToken({ uid: user.id, exp: Date.now() + 1000 * 60 * 60 * 24 * 30 });
    return json(res, 200, { ok: true, token, user: cleanUser(user) });
  }

  const session = auth(req);
  if (!session) return json(res, 401, { ok: false, error: 'Требуется вход в аккаунт' });
  const me = session.user;

  if (req.method === 'GET' && pathname === '/api/me') return json(res, 200, { ok: true, user: cleanUser(me) });

  if (req.method === 'GET' && pathname === '/api/users') {
    if (me.role !== 'teacher') return json(res, 403, { ok: false, error: 'Недостаточно прав' });
    return json(res, 200, { ok: true, users: db.users.filter(u => u.role === 'student').map(cleanUser) });
  }

  if (req.method === 'POST' && pathname === '/api/students') {
    if (me.role !== 'teacher') return json(res, 403, { ok: false, error: 'Недостаточно прав' });
    const body = await readBody(req);
    const login = String(body.login || '').trim();
    if (!login || !body.password || !body.name) return json(res, 400, { ok: false, error: 'Заполните имя, логин и пароль' });
    if (db.users.some(u => u.login === login)) return json(res, 409, { ok: false, error: 'Такой логин уже существует' });
    const student = {
      id: makeId(), role: 'student', name: String(body.name).trim(), class: Number(body.class || 2),
      subject: String(body.subject || 'Математика'), login,
      passwordHash: hashPassword(body.password), paid: !!body.paid, muted: false,
      theme: String(body.theme || 'blue'), gradeHistory: [], taskHistory: [], deletedReason: '', createdAt: Date.now()
    };
    db.users.push(student); writeDb();
    return json(res, 201, { ok: true, user: cleanUser(student) });
  }

  if (req.method === 'PUT' && pathname.startsWith('/api/students/')) {
    if (me.role !== 'teacher') return json(res, 403, { ok: false, error: 'Недостаточно прав' });
    const id = pathname.split('/').pop();
    const student = db.users.find(u => u.id === id && u.role === 'student');
    if (!student) return json(res, 404, { ok: false, error: 'Ученик не найден' });
    const body = await readBody(req);
    for (const key of ['name', 'class', 'subject', 'paid', 'muted', 'theme']) if (body[key] !== undefined) student[key] = body[key];
    if (body.grade !== undefined || body.comment !== undefined) {
      student.gradeHistory ??= [];
      student.gradeHistory.push({ id: makeId(), grade: String(body.grade ?? ''), comment: String(body.comment ?? ''), time: Date.now() });
    }
    if (body.task) {
      student.taskHistory ??= [];
      student.taskHistory.push({ id: makeId(), text: String(body.task), time: Date.now() });
    }
    writeDb(); return json(res, 200, { ok: true, user: cleanUser(student) });
  }

  if (req.method === 'DELETE' && pathname.startsWith('/api/students/')) {
    if (me.role !== 'teacher') return json(res, 403, { ok: false, error: 'Недостаточно прав' });
    const id = pathname.split('/').pop();
    const idx = db.users.findIndex(u => u.id === id && u.role === 'student');
    if (idx < 0) return json(res, 404, { ok: false, error: 'Ученик не найден' });
    db.users.splice(idx, 1); delete db.messages[id]; writeDb();
    return json(res, 200, { ok: true });
  }

  if (req.method === 'GET' && pathname.startsWith('/api/messages/')) {
    const id = pathname.split('/').pop();
    if (me.role === 'student' && me.id !== id) return json(res, 403, { ok: false, error: 'Недостаточно прав' });
    if (me.role === 'teacher' && !db.users.some(u => u.id === id && u.role === 'student')) return json(res, 404, { ok: false, error: 'Ученик не найден' });
    return json(res, 200, { ok: true, messages: db.messages[id] || [] });
  }

  if (req.method === 'POST' && pathname.startsWith('/api/messages/')) {
    const id = pathname.split('/').pop();
    const student = db.users.find(u => u.id === id && u.role === 'student');
    if (!student) return json(res, 404, { ok: false, error: 'Ученик не найден' });
    if (me.role === 'student' && me.id !== id) return json(res, 403, { ok: false, error: 'Недостаточно прав' });
    if (me.role === 'student' && student.muted) return json(res, 403, { ok: false, error: 'Репетитор временно запретил отправку сообщений' });
    const body = await readBody(req);
    const text = String(body.text || '').trim();
    const photo = body.photo ? String(body.photo) : '';
    if (!text && !photo) return json(res, 400, { ok: false, error: 'Пустое сообщение' });
    if (photo && !photo.startsWith('data:image/')) return json(res, 400, { ok: false, error: 'Недопустимое изображение' });
    const msg = { id: makeId(), from: me.role, text, photo, time: Date.now() };
    (db.messages[id] ??= []).push(msg); writeDb();
    return json(res, 201, { ok: true, message: msg });
  }

  if (req.method === 'PUT' && pathname === '/api/account') {
    const body = await readBody(req);
    if (body.name !== undefined) me.name = String(body.name).trim() || me.name;
    if (me.role === 'teacher' && body.login !== undefined) {
      const login = String(body.login).trim();
      if (db.users.some(u => u.id !== me.id && u.login === login)) return json(res, 409, { ok: false, error: 'Такой логин уже существует' });
      me.login = login;
    }
    if (me.role === 'teacher' && body.password) me.passwordHash = hashPassword(body.password);
    if (body.theme) me.theme = String(body.theme);
    writeDb(); return json(res, 200, { ok: true, user: cleanUser(me) });
  }

  return json(res, 404, { ok: false, error: 'Маршрут не найден' });
}

const server = http.createServer((req, res) => {
  route(req, res).catch(err => {
    console.error(err);
    json(res, err.code === 413 ? 413 : 500, { ok: false, error: err.code === 413 ? 'Слишком большой запрос' : 'Ошибка сервера' });
  });
});
server.listen(PORT, HOST, () => console.log(`SUPER_REPETITOR server listening on ${HOST}:${PORT}`));
